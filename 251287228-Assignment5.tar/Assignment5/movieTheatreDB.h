#ifndef MOVIETHEATREDB_H
#define MOVIETHEATREDB_H

// Constants used for the movies and actors
#define MAX_NAME_LEN  50
#define MAX_LINK_LEN 50
#define MAX_TITLE_LEN 100
#define MAX_GENRE_LEN 25

// True false booleans
#define TRUE 1
#define FALSE 0

#endif //MOVIETHEATREDB_H
